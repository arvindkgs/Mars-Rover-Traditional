class IllegalMoveException : Throwable() {

}
